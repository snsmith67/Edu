<?php
/*
Plugin Name: Thim Chameleon
Plugin URI: http://thimpress.com
Description: A custom box for changing theme's style.
Version: 1.0
Author: ThimPress
Author URI: http://thimpress.com/
Text Domain: tp-chameleon
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Some defines
define( 'TP_CHAMELEON_PATH', plugin_dir_path( __FILE__ ) );
define( 'TP_CHAMELEON_URL', plugin_dir_url( __FILE__ ) );

// Include features
require_once( TP_CHAMELEON_PATH . 'inc/fonts.php' );
require_once( TP_CHAMELEON_PATH . 'inc/functions.php' );