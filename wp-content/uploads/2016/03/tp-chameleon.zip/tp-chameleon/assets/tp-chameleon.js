(function ($) {
	$(function () {
		// Add Color Picker to all inputs that have 'color-field' class
		$('.chameleon-color-picker').wpColorPicker();

		// Add a style for color picker box
		$('.wp-picker-holder').css('position', 'absolute');
	});
})(jQuery);